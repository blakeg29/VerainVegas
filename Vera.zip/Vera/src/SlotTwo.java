
public class SlotTwo {

	
	public static int slotTwo(int quarters, int plays[], int count) {
		int quartersOut = 75;
		double moneyTotal = 0;
		count++;
		plays[count] = count;
		if(plays[count] == 69) {
			quarters += quartersOut;
			for(int i = 0; i < plays.length; i++) {
				plays[i] = 0;
			}
			moneyTotal = quarters/4.00;
			System.out.println("You won 75 quarters on slot 2 you have " + quarters + " quarters remaining which equals $" + moneyTotal);
		} else if (plays[count] < 69) {
			quarters--;
		}
		
		
		return quarters;
	}
}
