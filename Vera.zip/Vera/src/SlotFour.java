
public class SlotFour {

	
	public static int slotFour(int quarters, int plays[], int count) {
		int quartersOut = 2;
		double moneyTotal = 0;
		count++;
		plays[count] = count;
		if(plays[count] == 5) {
			quarters += quartersOut;
			for(int i = 0; i < plays.length; i++) {
				plays[i] = 0;
			}
			moneyTotal = (double)quarters / 4.00;
			System.out.println("You won 2 quarters on slot four you have " + quarters + " quarters remaining which equals $" + moneyTotal);
		} else if (plays[count] < 5) {
			quarters--;
		}
		
		
		return quarters;
	}	
		
}
