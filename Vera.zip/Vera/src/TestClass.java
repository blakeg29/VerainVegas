import java.io.*;
import java.util.*;

//Blake Cannoe
//Blake Gibson
public class TestClass {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		//Arrays to keep track of the amount of machine
		int[] playsSlotOne = new int[32];
		int[] playsSlotTwo = new int[70];
		int[] playsSlotThree = new int[8];
		int[] playsSlotFour = new int[6];
		int quarters = 0;
		int choice = 0;
		//each machine has a seperate count to keep track of all plays together as well as seperatly
		int countOne = 0;
		int countTwo = 0;
		int countThree = 0;
		int countFour = 0;
		int countTotal = 0;
		quarters = getQuarters(quarters);

		while (quarters > 0 && choice != 6) {

			do {

				String message = "Enter a selection\n";
				message += "1. Slot machine 1\n";
				message += "2. Slot machine 2\n";
				message += "3. Slot machine 3\n";
				message += "4. Slot machine 4\n";
				message += "5. Display quarters\n";
				message += "6. Quit\n";

				System.out.println(message);
				choice = scan.nextInt();

				// int[] playsSlotOne = new int [count];
				// int[] playsSlotTwo = new int [count];
				// int[] playsSlotThree = new int[count];
				// int[] playsSlotFour = new int [count];

				switch (choice) {
				case 1:
					countOne++;
					//resets the count after each win to keep the array from going out of bounds
					if (countOne >= 31) {
						countOne = 0;
					}
					//goes to the class for the first slot
					quarters = SlotOne.slotOne(quarters, playsSlotOne, countOne);
					//adds to the total number of plays
					countTotal++;
					break;

		
				case 2:
					countTwo++;
					if (countTwo >= 69) {
						countTwo = 0;
					}
					//goes to the class for the second slot
					quarters = SlotTwo.slotTwo(quarters, playsSlotTwo, countTwo);
					countTotal++;
					break;

				case 3:
					countThree++;
					if (countThree >= 7) {
						countThree = 0;
					}
					//goes to the class for the third slot
					quarters = SlotThree.slotThree(quarters, playsSlotThree, countThree);
					countTotal++;
					break;
					
				case 4:
					countFour++;
					if (countFour >= 5) {
						countFour = 0;
					}
					//goes to the class for the fourth slot
					quarters = SlotFour.slotFour(quarters, playsSlotFour, countFour);
					
					countTotal++;
					break;

				case 5:
					//prints out the quarters remaining
					System.out.println(quarters);
					break;

				case 6:
					//the user leaves before they run out of quarters
					System.out.println("Goodbye");
					System.out.println(" You played: " + countTotal + " times");
					break;
				default:
					System.out.println("Invalid");
					break;

				}

				

			} while (choice != 6 && quarters > 0);

		}
		//The user runs out of quarters the program ends
		if (quarters <= 0) {
			System.out.println("Sorry you are broke");
			System.out.println(" You played: " + countTotal + "times");
		}

	}

	public static int getQuarters(int quarters) {
		//gets the quarters from the user
		Scanner scan = new Scanner(System.in);
		System.out.println("How many quarters do you have");
		quarters = scan.nextInt();
		return quarters;

	}
	
	
		
	

		
		
	
	

}
