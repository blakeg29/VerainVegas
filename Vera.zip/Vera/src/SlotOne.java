// everything here is the same for the other three slots
public class SlotOne {
	
	
	public static int slotOne(int quarters, int plays[], int count) {
		//quarter pay out 
		int quartersOut = 25;
		
		double moneyTotal = 0;
		count++;	
		//populates the array
		plays[count] = count;
		//winning condition
		if(plays[count] == 31) {
			
			quarters += quartersOut;
			//resets the array after the win
			for(int i = 0; i < plays.length; i++) {
				plays[i] = 0;
			}
			//prints out the total amount of money left
			moneyTotal = (double) quarters/4.00;
			System.out.println("you won 25 quarters on slot 1 you have " + quarters + " quarters which equals $" + moneyTotal);
		
			//losing condition
		} else if (plays[count] < 31) {
				quarters--;
			}
		
			
		
		
		return quarters;
	
	
		
	}	

}
