
public class SlotThree {

	public static int slotThree(int quarters, int plays[], int count) {
		int quartersOut = 7;
		double moneyTotal = 0;
		count++;
		plays[count] = count;
		if(plays[count] == 7) {
			quarters += quartersOut;
			for(int i = 0; i < plays.length; i++) {
				plays[i] = 0;
			}
			moneyTotal = quarters/4.00;
			System.out.println("You won 7 quarters on slot 3 you have " + quarters + " quarters remaining which equals $" + moneyTotal);
		} else if (plays[count] < 7) {
			quarters--;
		}
		
		
		return quarters;
	}
	
}
